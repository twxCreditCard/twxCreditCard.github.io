<template>
  <div>
    <div class="jump col-xs-12 col-sm-12 col-md-12">
      <h3>汇丰生活信用卡</h3>
      <div>极致之选</div>
      <div>把握每个美好瞬间，就在此时此刻</div>
      <div class="subBtn">
        <el-button type="danger" @click="doApplicate" size="small">立即申请</el-button>
      </div>
      <div class="hfCard">
        汇丰生活信用卡
      </div>
      <div class="hfImg" style="text-align: center">
        <img src="/static/img/chn.jpg" alt="">
      </div>
      <div style="text-align: center">汇丰生活人民币白金卡</div>
      <div class="hfImg" style="text-align: center">
        <img src="/static/img/usa.jpg" alt="">
      </div>
      <div style="text-align: center">汇丰生活美元白金卡</div>
      <div class="disc">
        汇丰银行国内首发汇丰生活信用卡，其包含一张人民币银联白金卡和一张美元MasterCard白金卡。
        作为一张标准白金卡，汇丰生活信用卡力求为追求时尚潮流的您私人定制全方位的最潮用卡体验。<br>
        <span style="color: red;">*</span> 目前，每位客户仅限申领一套信用卡，不可兼得。
      </div>
      <div class="feeStandard">
        <h5>收费标准</h5>
        <div class="feeContent">
          汇丰生活信用卡主卡年费人民币300元，内含多项专属权益。首年激活卡片后免收首年年费，刷卡满6次可免次年年费。附属卡免收年费。
        </div>
      </div>
      <div>
        <h5>特色权益与优惠活动</h5>
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="潮好礼" name="first">
            <img src="/static/img/gifts.jpg" alt=""><br>
            开卡享好礼
            刷卡好礼：2018年06月 01日-2018年09月30日期间申请汇丰生活信用卡，
            卡片获批后60天内激活并在此60天期限内消费1笔，且该笔原始积分消费（包含支付宝、财付通消费）
            金额满等值人民币66元（含），即可在满足活动条件后2个月内通过汇丰中国权益平台“荟·赏 掌中世界”领取阿尔卑斯20寸拉杆箱。
            或2018年06月 01日-2018年09月30日期间申请汇丰生活信用卡，卡片获批后60天内激活并在此60天期限内消费1笔，
            且该笔原始积分消费（包含支付宝、财付通消费）金额满等值人民币288元（含），
            即可在满足活动条件后2个月内通过汇丰中国权益平台“荟·赏 掌中世界”领取阿尔卑斯20寸拉杆箱或Oral B 牙刷+乐扣保温杯礼盒套装。
          </el-tab-pane>
          <el-tab-pane label="潮旅行" name="second">
            <img src="/static/img/travel.jpg" alt=""><br/>
            境内外卡组织专享优惠
            银联全球精选酒店礼遇 <br>
            <span style="color: red;">*</span>详情请阅 <a href="http://unionpay.lychee.com">http://unionpay.lychee.com</a><br>
            <img src="/static/img/sleep.jpg" alt=""><br/>
            9元“汇”出行
            活动期间，当月累计可计积分消费满人民币2,888元或等值美元，
            次月可享1次以9元优惠价购买途牛旅行网火车票预订优惠券的权益。
            凭单个优惠券码登录途牛旅行网购买火车票可抵50元订单金额，
            剩余订单金额须使用汇丰中国银联人民币信用卡完成支付。
          </el-tab-pane>
          <el-tab-pane label="潮保障" name="third">
            <img src="/static/img/twoPeople.jpg" alt=""><br/>
            48小时失卡保障
            如您的汇丰生活信用卡因发生丢失或失窃或抢夺/抢劫导致被非法占用，
            在正式挂失前48小时内因信用卡盗刷产生一般消费交易所致的资金损失，
            可获得最高1万元人民币的失卡保障服务。<br>
            <img src="/static/img/plane.jpg" alt=""><br/>
            更多安心保障
            汇丰还为持卡人提供紧急预借现金服务等更多安心保障服务。
          </el-tab-pane>
          <el-tab-pane label="潮生活" name="fourth">
            <img src="/static/img/movie.png" alt=""><br>
            <span style="color: red;">*</span>9元约“汇”看电影<br>
            活动期间，当月累计可计积分消费满人民币2,888元或等值美元，
            次月可享2次以9元优惠价购买指定电影票券服务平台兑换券权益。<br>
            <img src="/static/img/happy.png" alt=""><br>
            <span style="color: red;">*</span>五星酒店自助餐买一赠一 <br>
            活动期间，当月累计可计积分消费满人民币2888元或等值美元，
            次月可享“五星酒店”豪华自助餐买一赠一“权益；
            酒店品牌包括丽思卡尔顿、威斯汀、香格里拉、希尔顿、凯宾斯基、喜来登、洲际等。<br>
            <img src="/static/img/home.jpg" alt=""><br>
            <span style="color: red;">*</span>全球商户特惠<br>
            您可享汇丰全球home&Away特惠商户丰富的优惠权益。包括折扣、买一赠一及各类独家专享尊贵权益，
            覆盖购物、餐饮、旅游休闲、健康美容等品类。
          </el-tab-pane>
        </el-tabs>
      </div>
      <div class="condition">
        <h5>申请条件</h5>
        <div>
          主卡申请人需年满18周岁，
          境内居民申请需月薪达人民币4,000元或以上，
          境外居民申请需月薪达人民币10,000元或以上。
          附属卡申请人须年满16周岁。
        </div>
      </div>
    </div>
    <div class="bottomContent" style="margin-top: 45px">
      <span @click="doApplicate">立即申请</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'creditCarDetail',
  data () {
    return {
      activeName: 'first',
    }
  },
  methods: {
    doApplicate() {
      this.$router.push({ path: '/submitForm' });
    },
    handleClick() {},
  },
}
</script>

<style scoped>
.jump{
  width: 100%;
  height: 180px;
  background: #EDEDED;
  padding: 10px;
}
.jump div {
  text-align: left;
  font-size: 18px;
  margin: 5px 0 12px 5px;
}
.jump>.subBtn{
  text-align: right;
}
.jump>.hfCard{
  border-radius: 4px;
  width: 98%;
  margin: 0 auto;
  height: 45px;
  line-height: 45px;
  background: #3E505E;
  color: #FFF;
  text-align: center;
  margin-top: 20px;
}
.jump>.hfImg>img{
  width: 244px;
  height: 155px;
}
.jump>.disc{
  text-align: left;
  word-wrap: break-spaces;
  text-indent: 40px;
}
.bottomContent{
  width: 100%;
  height: 45px;
  background: red;
  text-align: center;
  line-height: 45px;
  color: #FFF;
  position: fixed;
  bottom: 0;
}
.jump>.condition{
  margin-bottom: 55px;
}
</style>
