import Vue from 'vue'
import Router from 'vue-router'
import creditCarDetail from '@/components/creditCarDetail'
import submitForm from '@/components/submitForm'

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: '/',
      name: 'creditCarDetail',
      component: creditCarDetail
    },
    {
      path: '/creditCarDetail',
      name: 'creditCarDetail',
      component: creditCarDetail
    },
    {
      path: '/submitForm',
      name: 'submitForm',
      component: submitForm
    }
  ]
})
