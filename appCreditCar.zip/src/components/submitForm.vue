<template>
  <div>
    <mt-field label="姓名" placeholder="请输入姓名" v-model="ruleForm.name"></mt-field>
    <mt-field label="电话" placeholder="请输入手机号" type="tel" v-model="ruleForm.phone"></mt-field>
    <mt-field label="公司座机" placeholder="请输入公司座机" v-model="ruleForm.companyPhone"></mt-field>
    <mt-field label="公司名称" placeholder="请输入公司名称" v-model="ruleForm.companyName"></mt-field>
    <mt-field label="公司地址" placeholder="请输入公司地址" v-model="ruleForm.companyAddress"></mt-field>
    <mt-field label="住宅地址" placeholder="请输入住宅地址" v-model="ruleForm.houseAddress"></mt-field>
    <mt-field label="预约时间" placeholder="请输入预约时间" type="date" v-model="ruleForm.time"></mt-field>
    <div style="margin-top: 50px">
      <mt-button @click="submitForm" size="large" type="primary">提交</mt-button>
    </div>
    <div style="margin-top: 50px">
      <mt-button @click="goBackDetails" size="large" type="default">返回主页</mt-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      ruleForm: {
        name: '', phone: '', companyPhone: '', companyName: '', companyAddress: '', houseAddress: '', time: ''
      }
    }
  },
  methods: {
    submitForm() {
      for(const v in this.ruleForm) {
        if (this.ruleForm[v] === ''){ this.$message.warning(`${v}选项不能为空！`); return }
      }
      $.ajax({
        data: this.ruleForm,
        type: 'get',
        url: 'http://localhost:9999/subForm'
      }).done((res)=>{
        const data = JSON.parse(res);
        if (data.ok) { this.$message.success('提交成功！'); this.goBackDetails() }
      }).fail((res)=>{ this.$message.error('服务器报错！') });
    },
    goBackDetails(){
      this.$router.push({ path: '/creditCarDetail' });
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.toTop{
  margin-top: 10px;
}
</style>
