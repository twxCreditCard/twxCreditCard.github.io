const http = require('http');
const url = require('url');
http.createServer((request, response)=> {
  // 1. 请求处理
  try{
    const urlObject = url.parse(request.url, true);
    const params = urlObject.query;
    const result = { msg: 'ok', ok: true };
    console.log(params);
    //2. 响应处理
    response.writeHead(200, {
      "Content-Type": "jston/application",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST",
      "Access-Control-Allow-Headers": "x-requested-with,content-type"
    });
    response.write(JSON.stringify(result));
  }catch(e){
    // 2. 响应处理
    response.writeHead(200, {
      "Content-Type": "json/application",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST",
      "Access-Control-Allow-Headers": "x-requested-with,content-type"
    });
    response.write(JSON.stringify({
      "code":500,
      "msg":"服务器端错误！"+e.message
    }));
  }
  response.end();
}).listen(9999, function() {
  console.log(`App listening on port` + 9999 + '!');
});

process.on('uncaughtException', (err)=> {
  console.log('Caught exception: ', err);
});
